<?php

$a=8;
$b=6;
echo $a+$b;

?>