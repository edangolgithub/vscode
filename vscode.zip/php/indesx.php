<?php 

for ($i=0; $i <10 ; $i++) { 
  echo "<h1>".$i."</h1>";
}
$i=1;
do
{
    echo $i;
    $i++;
}while($i<=10);

$i=1;
while($i<=10)
{
    echo $i;
    $i++;
}




?>