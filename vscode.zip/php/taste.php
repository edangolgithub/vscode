<?php
$txt="php";
echo "i love" . $txt;





?>