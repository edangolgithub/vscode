<?php
$a=5;
if($a)
{
    echo "it is odd number";
}
else{
    echo "it is even number";
}





?>