﻿$(document).ready(start);


function start() {



    alert("all loaded");


};

$(document).ready(function () {

    

});