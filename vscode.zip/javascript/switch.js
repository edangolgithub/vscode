a=6;
if(a==6)
{
alert(6);
}
else if(a==7)
{
    alert(7);
}
else if(a==8)
{
    alert(8);
}
else
{
    alert("nothing");
}
switch(a)
{
    case 6:
    alert(6);
    break;
    case 7:
    alert(7);
    break;
    case 8:
    alert(8);
    break;
    default:
    alert("nothing");
    break;
}