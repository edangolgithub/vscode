//no return no param  1
//return noparam      2
//no return param     3
//return param        4


function f1()
{
alert("hi");
}

function f2()
{
    return "hello";
}

function f3(a,b)
{
    alert(a+b);
}

function f4(a,b,vc)
{
    return a+b+vc;
}

alert(f4(2,3,4));

