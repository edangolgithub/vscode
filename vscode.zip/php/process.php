<?php
echo "welcome ".$_REQUEST["name"];
echo "\nyou are from".$_REQUEST["adress"];
?>