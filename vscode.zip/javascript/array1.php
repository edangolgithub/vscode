<?php
$car=array("apple","ball","cat","dog");
echo "i like ".$car[0] .",".$car[1].",".$car[3];




?>