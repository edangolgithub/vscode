<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="css/bootstrap.css" rel="stylesheet" />
</head>
<body>
<div class="container jumbotron">
    <form action="process.php" class="form">
        
    <div class="form-group">
    
    <input type="text" class="form-control" id="email" placeholder="name" name="name">
  </div>
  <div class="form-group">
    
    <input type="text" class="form-control" placeholder="address" id="pwd" name="adress">
  </div>
  
  <button type="submit" class="btn btn-danger">Submit</button>
    </form>
    </div>
</body>
</html>