
class Abc
{
public static void main(String[] args) {
 System.out.println("hello"); 
 System.out.println("hello how are ypou");  
}
}