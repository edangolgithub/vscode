<?php

$email="linus@gmail.com"
function test($email)
{
    for($i=0;$i< =strlen($email);$i++)
    {
        if()
    }
}


?>
