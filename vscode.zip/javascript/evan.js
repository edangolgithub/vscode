function add()
{
    var a=2;
    var b=2;
    document.getElementById("pq").innerHTML=a+b;
    document.getElementById("pq").style.color="red";
}
function clear1()
{
    document.getElementById("pq").style.color="blue";
}


