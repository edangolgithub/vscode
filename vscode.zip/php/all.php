<?php
$d="hello world";
echo $d;


?>