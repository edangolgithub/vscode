<?php

echo strlen($_GET['val']);
?>