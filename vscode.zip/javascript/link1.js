function f1()
{
    var a=4
    var b=4
    document.getElementById("abc").innerHTML=a+b;

}
f1();

function f2()
{
alert("hi");
}
f2();
function f3()
{
     alert(a+b);
}
f3();