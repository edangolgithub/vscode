<?php
//arithematic + - * / %
//relational < > == >= <= !=
//logical && || !
$a=1;  //linus
$b=2;  // key
$c=$a^$b; //generated password // 3

echo $c;

echo 2   ^  3;

$x="hello";
$x.="hi";// $x=$x."hi";

echo $x;
?>