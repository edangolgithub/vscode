<?php
$a=9;
$b=8;
echo $a+$b;



?>