<?php

echo $_GET['fname'];
echo $_GET['lname'];
?>