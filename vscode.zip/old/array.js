﻿


var nums = [1, 4, 5, 2, 7, 3];

var cars = new Array("Saab", "Volvo", "BMW");

document.write(cars[1]);