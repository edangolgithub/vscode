<?php
$i=1;
if($i==40)
{
    echo 40;
}
else if($i==50)
{
    echo 50;
}
else{
    echo 90;
}
switch($i)  
{
    case 40:
    echo 40;
break;
case 50:
echo 50;
break;
default:
echo 90;
}

?>