<?php

$var=$_REQUEST['abc'];
echo $var;
echo $_POST['d'];
?>