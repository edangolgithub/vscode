﻿//alert("hello");

function linus() {
    document.getElementById("demo").innerHTML = "sl;kadj";
}
function binas() {
    document.getElementById("demo").innerHTML = "";
}
