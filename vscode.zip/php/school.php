<?php 



$a= "   dkjfhdji    ";

echo trim($a);