#include<stdio.h>



int main()
{

int a=(3>5)?3:5;

printf("%d",a);


}
